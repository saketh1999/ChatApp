package com.example.kacchat;

public class GroupMessagesAdapter {
}
